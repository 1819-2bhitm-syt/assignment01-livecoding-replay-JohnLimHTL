let data = {
    name: "Welt"
};

module.exports = data;