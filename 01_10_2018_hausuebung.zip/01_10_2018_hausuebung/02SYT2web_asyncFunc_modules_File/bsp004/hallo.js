let data = {
    name: "Welt"
};