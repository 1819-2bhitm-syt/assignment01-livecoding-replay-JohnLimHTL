function hallo(who) {
    console.log("Hallo " +who);
}

hallo("Welt!");