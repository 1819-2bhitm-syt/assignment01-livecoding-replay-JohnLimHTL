funtion hallo(who) {
    console.log("Hallo " + who);
}

funtion getName() {
    return "Welt";
}

console.log(getName());